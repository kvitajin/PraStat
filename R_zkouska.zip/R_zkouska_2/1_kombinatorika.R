# V(n,k) 

variace = function(n,k) 
{
  citatel = factorial(n)  
  jmenovatel = factorial(n-k)
  return(citatel/jmenovatel)
}

# V*(n,k) 

variace_opak = function(n,k) {
  return(n^k)
}

#P(n) 

permutace = function(n){
  return(factorial(n))
}

# P*(n1,n2,n3,....,nk)

permutace_opak = function(vec_n) 
{
  n = sum(vec_n) # 
  citatel = factorial(n) 
  jmenovatel = prod(factorial(vec_n)) 
  return(citatel/jmenovatel)
}

# C(n,k)

kombinace = function(n,k)
{
  return(choose(n,k)) 
}

# C*(n,k) 

kombinace_opak = function(n,k)
{
  return(choose(n+k-1,k)) 
}

# kombinace(10,4)
# kombinace(10,6)
# variace_opak(10, 4)
# kombinace(40,2)

# a = c(2,3,2,2,1)
# permutace_opak(a)
# kombinace_opak(6, 4)
