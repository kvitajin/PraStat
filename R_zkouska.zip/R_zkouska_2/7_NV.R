data = c(1/3, 1/6, 
         0, 1/6, 
         1/6, 0)
P = matrix(data , nrow=3, ncol=2) #případně byrow = ...
X = c(0, 1)
Y = c(-2, 1, 3)
dimnames(P) = list(Y,X)

p_3_1 = 1 - sum(P)
P["3","1"] = p_3_1
P

F = matrix(rep(0,3*2), nrow=4, ncol=3)
dimnames(F) = list(c('(-inf,-2>', '(-2,1>', '(1,3>', '(3,inf)'),
                   c('(-inf,0>', '(0,1>', '(1,inf)'))
F

x_vals = c(0,1,2)
y_vals = c(-2,1,3,4)
for(i in 1:4){
  for(j in 1:3){
    x = x_vals[j]
    y = y_vals[i]
    F[j,i] = sum(P[Y<y, X<x])
  }
}
F

P_x = rowSums(P)
P_x

F_x = c(0, cumsum(P_x))
F_x

P_y = colSums(P)
P_y

F_y = c(0, cumsum(P_y))
F_y

x_vals = c(3,5,7,8)
y_vals = c(1,2,3,4,5)
for(i in 1:4){
  for(j in 1:5){
    x = x_vals[i]
    y = y_vals[j]
    F[i,j] = sum(P[X<x, Y<y])
  }
}
F
