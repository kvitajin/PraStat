#### 2

#### a 
# Pravděpodobnostní funkce P(X = x)
x = c(0,1,2,3)   # hodnota, pro níž hledáme p-stní funkci 
N = 7  # celkový počet objektů
M = 3   # z toho se zadanou vlastností
n = 4  # velikost výběru
dhyper(x, M, N - M, n)

a = c(0.029,0.343, 0.514, 0.114)
sum(a)

dist.f = function(x,p){
  F = cumsum(p)
  F_ext = c(0, F) # natáhneme F o 0 na začátku
  x_ext = c(x[1]-1, x, x[length(x)]+1) # a x z obou stran
  
  plot(x, F, ylab="F(x)", xaxt='n', ylim=c(0,1), # prazdná kolečka
       type='p', main="Distribucni funkce") 
  par(new=TRUE) # že chceme kreslit do jednoho grafu
  plot(x, F_ext[1:(length(F_ext)-1)], # plná kolečka
       ylab="F(x)", xaxt='n', ylim=c(0,1), type='p', pch=19) 
  
  for(i in 1:(length(x_ext)-1)){
    lines(c(min(x)-100,max(x)+100), c(F_ext[i],F_ext[i]),
          type = 'l', lty = 3, lwd=0.5) # horizontální grid
    lines(c(x_ext[i],x_ext[i]), c(-0.1,1.1), 
          type = 'l', lty = 3, lwd=0.5) # vertikální grid
    lines(x_ext[i:(i+1)], c(F_ext[i],F_ext[i])) # graf - čáry
  }
  axis(1, at=x,labels=x) # nastavení hodnot na X
  axis(4, at=F,labels=F, las=2, cex.axis=0.7, tck=-.01) # a Y
  return(F)
}

dist.f(x, a)

#### b
souhrn=function(x,p){
  EX = sum(x*p)
  EX2 = sum(x*x*p)  
  DX = EX2-EX^2
  sigma.X = sqrt(DX)
  # zápis výsledků do tabulky
  tab = rbind(EX, DX, sigma.X)
  tab.popis = c("str. hodnota","rozptyl","smer. odchylka")
  rownames(tab) = tab.popis
  return(tab)
}

souhrn(x, a)

#### c
y = 200*x

pravd.f = function(x,p){
  plot(x, p, # plná kolečka - v skutečných hodnotách
       ylab='p(x)',xaxt='n',pch=19,ylim=c(0,max(p)),main="Pravdepodobnostni funkce") 
  lines(c(min(x)-100,max(x)+100),c(0, 0))
  for(i in 1:length(x)){
    lines(c(min(x)-100,max(x)+100), c(p[i],p[i]),
          type = 'l', lty = 3, lwd=0.5) # horizontální grid
    lines(c(x[i],x[i]), c(-0.1,1.1), 
          type = 'l', lty = 3, lwd=0.5) # vertikální grid
  }
  par(new=TRUE) # že chceme kreslit do jednoho grafu
  plot(x, p*0, # prázdná kolečka - tam kde je definovaná nenulová hodnota
       ylab='p(x)', xaxt='n', ylim=c(0,max(p)))
  axis(1, at=x,labels=x) # nastavení hodnot na X
  axis(4, at=p,labels=p, las=2, cex.axis=0.7, tck=-.01) # a Y
}

pravd.f(y, a)

#### d
souhrn(y,a)

#### 3
# vykreslíme si Hustotu pravděpodobnosti
lambda = 1/10
x = seq(from = 0, to = 100, by = 0.01)
f_x = dexp(x, lambda)
plot(x, f_x, type='l')
grid()

s = qexp(0.89, lambda)
s
x = seq(from = 0, to = 100, by = 0.01)
f_x = dexp(x, lambda)
plot(x, f_x, type='l')
grid()
#lines(c(0,1),c(0.89, 0.89))
lines(c(s,s),c(0, 11))
grid()


# P(X > 12)
((1 - pexp(12,lambda))*dexp(8,lambda))/dexp(8,lambda)

E_X = 10
lambda = 1/E_X
pnorm(13, mean=lambda, sd=sqrt((lambda^2)/40))
pnorm(13, mean=40*10, sd=sqrt(40*(lambda*lambda)))
