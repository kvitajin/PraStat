dolni_mez = 0 # dolni mez pro integral
horni_mez = 20 # horni mez pro integral

f_exp = expression(c*(40*x-x^2)) # funkce k pocitani v distribucni funkci

f_deriv = D(f_exp, "x") # vypocet derivace - vysledek zkopirovat do f = function
f_deriv

f = function(x){
  return(40 - 2 * x)
} 

c_konst = integrate(f, dolni_mez, horni_mez)$value
c_konst
# c = 1/c_konst

F.dist = function(x){
  res = 1/400*(40*x-x*x) # funkce k pocitani v distribucni funkci s vypocitanou konstantou
  res[x <= dolni_mez] = 0 # 0 pro x <= dolni mez
  res[x > horni_mez] = 1  # 1 pro x > horni mez
  return(res)
}

f.dens = function(x){
  res = 1/400*(40-2*x) # zadat vysledek z derivace s vypocitanou konstantou
  res[x <= dolni_mez] = 0 # 0 pro x <= dolni mez
  res[x > horni_mez] = 0  # 0/1 pro x > horni mez
  return(res)
}

# Vykresleni hustoty pravdepodobnosti
x = seq(from = dolni_mez - 2, to = horni_mez + 2, by = 0.01) # body na ose x
fx = f.dens(x) # hodnoty f(x)
plot(x, fx, cex=0.2) # vykreslit tečky (cex je velikost)

# Vykresleni distribucni funkce
x = seq(from = dolni_mez - 2, to = horni_mez + 2, by = 0.001) # body na ose x
FX = F.dist(x)
plot(x, FX, type='l')

# E(X)
x_fx = function(x){
  fx = f.dens(x)
  return(x*fx)
} 

# integrujeme jen tam kde víme, že je f(x) nenulová
E_X = integrate(x_fx, dolni_mez, horni_mez)$value
E_X

# E(X^2)
xx_fx = function(x){
  fx = f.dens(x) 
  return(x*x*fx)
}

# integrujeme jen tam kde víme, že je f(x) nenulová
E_XX = integrate(xx_fx, dolni_mez, horni_mez)$value
E_XX

# D(X)
D_X = E_XX - E_X^2
D_X

# sigma(x)
std_X = sqrt(D_X)
std_X


# vypocet medianu
x[FX >= 0.5][1] # první prvek z x pro který F(x)>=0.5

# vykresleni medianu
x = seq(from = dolni_mez - 2, to = horni_mez + 2, by = 0.001) # body na ose x
FX = F.dist(x)
plot(x, FX, type='l')
lines(c(dolni_mez - 2, horni_mez + 2),c(0.5, 0.5))

# vypocet pokud pocitame nejaky interval
integrate(f.dens, 5, 10)$value

# linearni trans.
25 - 1.2*E_X

# P(−2 ≤ X ≤ −0.5)
integrate(f.dens, -2, -0.5)$value
integrate(f.dens, -1, -0.5)$value

# P(−2 ≤ X ≤ −1)
integrate(f.dens, -2, -1)$value

# P(X = 0.3)
integrate(f.dens, 0.3, 0.3)$value

# Pokud je zadano Y
FY.dist = function(y){
  # spočteno ze vztahu FY(y) = P(Y < y) = P(3X + 1 < y) = ...
  x = (y-1)/3 
  FY = F.dist(x)
  return(FY)
}

# Vykresleni distribucni funkce pro Y
y = seq(from =  dolni_mez - 5, to = horni_mez + 50, by = 0.001) # body na ose x
FY = FY.dist(y)
plot(y, FY, type='l')

# derivace F_Y
dolni_mez_y = -2
horni_mez_y = 1

fY.dens = function(y){
  res = 2/9*(y + 2) # derivace y
  res[y < dolni_mez_y] = 0 # 0 pro x < dolni mez y
  res[y > horni_mez_y] = 0  # 0/1 pro x > horni mez y
  return(res)
}

integrate(fY.dens, dolni_mez_y, horni_mez_y)$value # kontrola celkového integrálu
y = seq(from = dolni_mez_y -2, to = horni_mez_y + 2, by = 0.001) # body na ose x
fY = fY.dens(y)
plot(y, fY, cex=0.2)

# E(Y)
y_fy = function(y){
  fy = fY.dens(y)
  return(y*fy)
} 

# integrujeme jen tam kde víme, že je f(y) nenulová
E_Y = integrate(y_fy, dolni_mez_y, horni_mez_y)$value
E_Y

# E(Y^2)
yy_fy = function(y){
  fy = fY.dens(y)
  return(y*y*fy)
} 

# integrujeme jen tam kde víme, že je f(y) nenulová
E_YY = integrate(yy_fy, dolni_mez_y, horni_mez_y)$value
E_YY

# D(Y)
D_Y = E_YY - E_Y^2
D_Y

# sigma(Y)
sqrt(D_Y)

