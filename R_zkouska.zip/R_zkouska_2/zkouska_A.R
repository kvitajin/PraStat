library(readxl)
library(lawstat)
library(FSA)
library(dplyr)
library(ggplot2)
library(moments)
library(rstatix)
library(dunn.test)

data = read_excel("/home/vlada/Downloads/zkouska_23_A.xlsx", sheet="lol", skip=0)
data = as.data.frame(data)

colnames(data) = c("ID", "FV", "SV", "Name")

d_all <- data %>% mutate("FV-SV" = FV - SV)
d_all <- d_all %>% mutate("SV-FV" = SV - FV)

outliers = d_all %>%
  group_by(Name) %>% 
  identify_outliers(SV)

d_all = d_all %>%
  mutate(hodnoty_out = ifelse(ID %in% outliers$ID, NA, SV))

d_NA = na.omit(d_all)

tapply(d_NA$SV, d_NA$Name, moments::skewness)
tapply(d_NA$SV, d_NA$Name, moments::kurtosis) - 3

tapply(d_NA$SV, d_NA$Name, shapiro.test) # Test normality

tapply(d_NA$SV, d_NA$Name, mean) # Bodove odhady pro stredni hodnotu

tapply(d_NA$SV, d_NA$Name, t.test, alternative = "greater", conf.level=0.9) # 90% levostranny IO

tapply(d_NA$SV, d_NA$Name, t.test, alternative = "greater", mu = 65, conf.level=0.95) # 90% levostranny IO se stredni hodnotou

tapply(d_NA$SV, d_NA$Name, t.test, alternative = "two.sided", mu = 65, conf.level=0.95)

prima = d_NA %>% filter(Name == "prima")
kvarta = d_NA %>% filter(Name == "kvarta")

# pokud p-hodnota < hlad. vyznamnosti druhe data jsou statisticky vyznamne vetsi
# pokud p-hodnota > hlad. vyznamnosti prvni data jsou statisticky vyznamne vetsi
var.test(prima$SV,kvarta$SV, alternative="two.sided", conf.level=0.9)




