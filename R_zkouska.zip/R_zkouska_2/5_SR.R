# ** Hustota pravděpodobnosti ####
# - začíná písmenkem d: p = d...(x, ...)
# 
# ** Distribuční funkce ####
# - začíná písmenkem p: p = P(X < x): p = p...(x, ...)
# 
# ** Kvantilová funkce ####
# - začíná písmenkem q:  najdi x pro zadané p: p = F(x) -> x = F^-1(p): x = q...(p, ...)


# * Exponenciální rozdělení: Exp(lambda) ####
# - doba do 1. události, doba mezi událostmi (pouze v období stabilního života - Poissonův proces)
# - parametr lambda je tentýž co v Poissonově rozdělení

# Hustota pravděpodobnosti f(x)
lambda = 2
x = 1
dexp(x, lambda)

# vykreslíme si Hustotu pravděpodobnosti
x = seq(from = 0, to = 6, by = 0.01)
f_x = dexp(x, lambda)
plot(x, f_x, type='l')
grid()

# Distribuční funkce F(x) = P(X < x)
lambda = 2
x = 1
pexp(x, lambda)

# vykreslíme si Distribuční funkci
x = seq(from = 0, to = 6, by = 0.01)
F_x = pexp(x, lambda)
plot(x, F_x, type = 'l')
grid()

# kvantilová funkce F^(-1)(p) = x: P(X<x)=p
lambda = 2
p = 0.5 
qexp(p, a, b)

# vykreslení - kvantilová funkce F^(-1)(p) = x
p = seq(from=0, to=1, by=0.001)   
x = qexp(p, lambda)
plot(p, x, type = 'l')
grid()

# E(X)
E_X = 1/lambda

# D(X)
D_X = 1/(lambda*lambda)





# * Weibullovo rozdělení: W(theta,beta)$ ####
# - doba do 1. události (poruchy)(vhodná volba β umožuje použití v libovolném období intenzity poruch)
# - rozšíření exponenciálního rozdělení Exp(λ) = W(Θ=1/λ, β=1)


# Hustota pravděpodobnosti f(x)
theta = 1/2 # ekvivalent 1/lambda u exp. rozdělení
beta = 1  # beta = 1 -> exponenciální rozdělení
x = 5
dweibull(x,shape=beta, scale=theta)

# vykreslíme si Hustotu pravděpodobnosti
x = seq(from = 0, to = 6, by = 0.01)
f_x = dweibull(x,shape=beta, scale=theta)
plot(x, f_x, type='l')
grid()

# Distribuční funkce F(x) = P(X < x)
theta = 3 # ekvivalent 1/lambda u exp. rozdělení
beta = 2  # beta = 1 -> exponenciální rozdělení
x = 5
pweibull(x,shape=beta, scale=theta)

# vykreslíme si Distribuční funkci
x = seq(from = 0, to = 6, by = 0.01)
F_x = pweibull(x,shape=beta, scale=theta)
plot(x, F_x, type = 'l')
grid()

# kvantilová funkce F^(-1)(p) = x: P(X<x)=p
theta = 3 # ekvivalent 1/lambda u exp. rozdělení
beta = 2  # beta = 1 -> exponenciální rozdělení
p = 0.5
qweibull(p,shape=beta, scale=theta)

# vykreslení - kvantilová funkce F^(-1)(p) = x
p = seq(from=0, to=1, by=0.01)   
x = qweibull(p,shape=beta, scale=theta)
plot(p, x, type = 'l')
grid()




# * Normální rozdělení: N(mu,sigma^2) ####
# - rozdělení modelující např. chyby měření, chování součtu/průměru mnoha jiných náhodných veličin
# - viz. Centrální limitní věta
# - mu je přímo střední hodnota rozdělení: E(X) = mu
# - sigma je přímo směrodatná odchyla rozdělení: D(X) = sigma^2 
# - s parametry mu=0,sigma=1 se nazývá normované Normální rozdělení


# Hustota pravděpodobnosti f(x)
mu = 2
sigma = 3
x = 4
dnorm(x, mean=mu, sd=sigma)

# vykreslíme si Hustotu pravděpodobnosti
x = seq(from = -5, to = 10, by = 0.01)
f_x = dnorm(x, mean=mu, sd=sigma)
plot(x, f_x, type='l')
grid()

# Distribuční funkce F(x) = P(X < x)
mu = 2
sigma = 3
x = 4
pnorm(x, mean=mu, sd=sigma)

# vykreslíme si Distribuční funkci
x = seq(from = -5, to = 10, by = 0.01)
F_x = pnorm(x, mean=mu, sd=sigma)
plot(x, F_x, type = 'l')
grid()

# kvantilová funkce F^(-1)(p) = x: P(X<x)=p
mu = 2
sigma = 3
p = 0.5
qnorm(p, mean=mu, sd=sigma)

# vykreslení - kvantilová funkce F^(-1)(p) = x
p = seq(from=0, to=1, by=0.01)   
x = qnorm(p, mean=mu, sd=sigma)
plot(p, x, type = 'l')
grid()
