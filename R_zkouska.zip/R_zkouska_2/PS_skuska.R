### 2

dolni_mez = 0 # dolni mez pro integral
horni_mez = 2 # horni mez pro integral
### a
f_exp = expression(x-x^2/4) # funkce k pocitani v distribucni funkci

f_deriv = D(f_exp, "x") # vypocet derivace - vysledek zkopirovat do f = function
f_deriv

f = function(x){
  return(1 - x/2)
} 

f.dens = function(x){
  res = 1 - x/2 # zadat vysledek z derivace s vypocitanou konstantou
  res[x <= dolni_mez] = 0 # 0 pro x <= dolni mez
  res[x > horni_mez] = 0  # 0/1 pro x > horni mez
  return(res)
}

# Vykresleni hustoty pravdepodobnosti
x = seq(from = dolni_mez - 2, to = horni_mez + 2, by = 0.01) # body na ose x
fx = f.dens(x) # hodnoty f(x)
plot(x, fx, cex=0.2) # vykreslit tečky (cex je velikost)

#### b
# E(X)
x_fx = function(x){
  fx = f.dens(x)
  return(x*fx)
} 

# integrujeme jen tam kde víme, že je f(x) nenulová
E_X = integrate(x_fx, dolni_mez, horni_mez)$value
E_X

F.dist = function(x){
  res = 1/400*(40*x-x*x) # funkce k pocitani v distribucni funkci s vypocitanou konstantou
  res[x <= dolni_mez] = 0 # 0 pro x <= dolni mez
  res[x > horni_mez] = 1  # 1 pro x > horni mez
  return(res)
}

FX = F.dist(x)

# vypocet medianu
x[FX >= 0.5][1] # první prvek z x pro který F(x)>=0.5

#### c
integrate(f.dens, 0, 1.5)$value
integrate(f.dens, 1, 2)$value
integrate(f.dens, 2, 2)$value

#### d


# E(X^2)
xx_fx = function(x){
  fx = f.dens(x) 
  return(x*x*fx)
}

# integrujeme jen tam kde víme, že je f(x) nenulová
E_XX = integrate(xx_fx, dolni_mez, horni_mez)$value
E_XX

# D(X)
D_X = E_XX - E_X^2
D_X


10 - 4*E_X
sqrt(16*D_X)
