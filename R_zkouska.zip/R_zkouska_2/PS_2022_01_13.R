#### 2
#### a
F = c(0, 0.1, 0.2, 0.5, 0.8, 1)
x = c(6,7,8,9,10)
p = diff(F)
p

#### b
p[x ==9]

#### c
sum(p[x >= 9])


#### d
souhrn=function(x,p){
  EX = sum(x*p)
  EX2 = sum(x*x*p)  
  DX = EX2-EX^2
  sigma.X = sqrt(DX)
  # zápis výsledků do tabulky
  tab = rbind(EX, DX, sigma.X)
  tab.popis = c("str. hodnota","rozptyl","smer. odchylka")
  rownames(tab) = tab.popis
  return(tab)
}

souhrn(x,p)


#### e
y = 40*x
souhrn(y,p)

##### 3
#### a
mu = 40
sigma = 7
# vykreslíme si Distribuční funkci
x = seq(from = 10, to = 50, by = 0.01)
F_x = pnorm(x, mean=mu, sd=sigma)
plot(x, F_x, type = 'l')
grid()

#### b
mp = qnorm(0.89, mean=mu, sd=sigma)
mp
x = seq(from = 10, to = 60, by = 0.01)
F_x = pnorm(x, mean=mu, sd=sigma)
plot(x, F_x, type = 'l')
grid()
lines(c(0,60),c(0.89, 0.89))
lines(c(mp,mp),c(0, 1))

#### c
a = ((1 - pnorm(41, mean = mu, sd=sigma))*(1 - pnorm(35, mean = mu, sd=sigma)))/(1 - pnorm(35, mean = mu, sd=sigma))
a

#### d
1 - pnorm(37, mean=40*mu, sd=sqrt(40*sigma^2))
1 - pnorm(37, mean = mu, sd=sigma)^40
1 - pchisq