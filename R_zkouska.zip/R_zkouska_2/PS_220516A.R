#### 2

x = c(0,1,2,3,4) # Jednotlive x hodnoty
p = c(0.12,0.04,0.3,0.48,0) # Jednotlive pravdepodobnosti

#### a
p[5] = round(1 - sum(p), digits=2)
p

dist.f = function(x,p){
  F = cumsum(p)
  F_ext = c(0, F) # natáhneme F o 0 na začátku
  x_ext = c(x[1]-1, x, x[length(x)]+1) # a x z obou stran
  
  plot(x, F, ylab="F(x)", xaxt='n', ylim=c(0,1), # prazdná kolečka
       type='p', main="Distribucni funkce") 
  par(new=TRUE) # že chceme kreslit do jednoho grafu
  plot(x, F_ext[1:(length(F_ext)-1)], # plná kolečka
       ylab="F(x)", xaxt='n', ylim=c(0,1), type='p', pch=19) 
  
  for(i in 1:(length(x_ext)-1)){
    lines(c(min(x)-100,max(x)+100), c(F_ext[i],F_ext[i]),
          type = 'l', lty = 3, lwd=0.5) # horizontální grid
    lines(c(x_ext[i],x_ext[i]), c(-0.1,1.1), 
          type = 'l', lty = 3, lwd=0.5) # vertikální grid
    lines(x_ext[i:(i+1)], c(F_ext[i],F_ext[i])) # graf - čáry
  }
  axis(1, at=x,labels=x) # nastavení hodnot na X
  axis(4, at=F,labels=F, las=2, cex.axis=0.7, tck=-.01) # a Y
  return(F)
}

### b
dist.f(x,p)

### c
sum(p[x>1])

### d
souhrn=function(x,p){
  EX = sum(x*p)
  EX2 = sum(x*x*p)  
  DX = EX2-EX^2
  sigma.X = sqrt(DX)
  # zápis výsledků do tabulky
  tab = rbind(EX, DX, sigma.X)
  tab.popis = c("str. hodnota","rozptyl","smer. odchylka")
  rownames(tab) = tab.popis
  return(tab)
}

souhrn(x,p)

### e
y = 150 + 90*x
souhrn(y,p)


##### 3

### a
# vykreslíme si pravděpodobnostní funkci
lt = 40
x = 20:60 # minimálně 0, maximum neomezeno
P_x = dpois(x, lt)
plot(x, P_x)
grid()

#### b
ppois(30, lt)

#### c
((1-ppois(41,lt))*dpois(32,lt))/dpois(32,lt)

#### d
# P(X >= 40) = 1 - P(X < 40) 
1 - pnorm(39*lt, 42*lt, sqrt(42*lt^2))


