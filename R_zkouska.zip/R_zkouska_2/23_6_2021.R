# Hustota pravděpodobnosti f(x)
mu = 44
sigma = 8


# vykreslíme si Distribuční funkci
x = seq(from = 20, to = 80, by = 0.01)
F_x = pnorm(x, mean=mu, sd=sigma)
plot(x, F_x, type = 'l')
grid()

a = qnorm(0.87, mean=mu, sd=sigma)
p = seq(from=20, to=80, by=0.01)   
x = pnorm(p, mean=mu, sd=sigma)
plot(p, x, type = 'l')
lines(c(0,1),c(a, a))
lines(c(a, a),c(0, 1))
grid()


(1 - pnorm(46, mean=mu, sd=sigma))/(1 - pnorm(35, mean=mu, sd=sigma)) # this

1 - pnorm(41, mean=mu, sd=sqrt(sigma^2/n))
