library(readxl)
library(lawstat)
library(FSA)
library(dplyr)
library(ggplot2)
library(moments)
library(rstatix)
library(dunn.test)

data = read_excel("/home/vlada/Downloads/zkouska_23_B.xlsx", sheet="lol", skip=0)
data = as.data.frame(data)

colnames(data) = c("ID", "FV", "SV", "Name")

d_all <- data %>% mutate("FV-SV" = FV - SV)
d_all <- d_all %>% mutate("SV-FV" = SV - FV)

outliers = d_all %>%
  group_by(Name) %>% 
  identify_outliers(SV)

d_all = d_all %>%
  mutate(hodnoty_out = ifelse(ID %in% outliers$ID, NA, SV))

d_NA = na.omit(d_all)

tapply(d_NA$SV, d_NA$Name, moments::skewness)
tapply(d_NA$SV, d_NA$Name, moments::kurtosis) - 3

tapply(d_NA$SV, d_NA$Name, shapiro.test) # Test normality

tapply(d_NA$SV, d_NA$Name, t.test, alternative = "two.sided") # Pokud normalita OK

tapply(d_NA$SV, d_NA$Name, symmetry.test, boot=FALSE) # Pokud normalita NENI OK

tapply(d_NA$SV, d_NA$Name, wilcox.test, alternative = 'two.sided') # Pokud symetrie OK

tapply(d_NA$SV, d_NA$Name, BSDA::SIGN.test, alternative = 'two.sided') # Pokud symetrie NENI OK

tapply(d_NA$SV, d_NA$Name, mean) # Bodove odhady pro stredni hodnotu
tapply(d_NA$SV, d_NA$Name, median) # Bodove odhady pro median

tapply(d_NA$SV, d_NA$Name, t.test, alternative = "greater", conf.level=0.9) # 90% levostranny IO
tapply(d_NA$SV, d_NA$Name, t.test, alternative = "less", conf.level=0.9) # 90% pravostranny IO

tapply(d_NA$SV, d_NA$Name, t.test, alternative = "greater", mu = 65, conf.level=0.9) # 90% levostranny IO se stredni hodnotou

tapply(d_NA$SV, d_NA$Name, t.test, alternative = "two.sided", mu = 65, conf.level=0.5)



shapiro.test(kvarta_poz$SV)$p.value
shapiro.test(kvarta_neg$SV)$p.value    

wilcox.test(kvarta_poz$SV, kvarta_neg$SV, alternative="two.sided", conf.level=0.95, conf.int=T)


var.test(kvarta_poz$SV,kvarta_neg$SV, alternative="two.sided",conf.level=0.95)

kvarta_poz = d_NA %>% filter(Name == "kvarta", SV > 65)
kvarta_neg = d_NA %>% filter(Name == "kvarta", SV <= 65)
kvarta_all = d_NA %>% filter(Name == "kvarta")
kvarta_pod = nrow(kvarta_poz)/nrow(kvarta_all)
kvarta_pod
prima_poz = d_NA %>% filter(Name == "prima", SV > 65)
prima_neg = d_NA %>% filter(Name == "prima", SV <= 65)
prima_all = d_NA %>% filter(Name == "prima")
prima_pod = nrow(prima_poz)/nrow(prima_all)
prima_pod


