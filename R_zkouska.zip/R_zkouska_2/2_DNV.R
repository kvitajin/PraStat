# Pravděpodobnostní funkce
pravd.f = function(x,p){
  plot(x, p, # plná kolečka - v skutečných hodnotách
       ylab='p(x)',xaxt='n',pch=19,ylim=c(0,max(p)),main="Pravdepodobnostni funkce") 
  lines(c(min(x)-100,max(x)+100),c(0, 0))
  for(i in 1:length(x)){
    lines(c(min(x)-100,max(x)+100), c(p[i],p[i]),
          type = 'l', lty = 3, lwd=0.5) # horizontální grid
    lines(c(x[i],x[i]), c(-0.1,1.1), 
          type = 'l', lty = 3, lwd=0.5) # vertikální grid
  }
  par(new=TRUE) # že chceme kreslit do jednoho grafu
  plot(x, p*0, # prázdná kolečka - tam kde je definovaná nenulová hodnota
       ylab='p(x)', xaxt='n', ylim=c(0,max(p)))
  axis(1, at=x,labels=x) # nastavení hodnot na X
  axis(4, at=p,labels=p, las=2, cex.axis=0.7, tck=-.01) # a Y
}

# Funkce pro výpočet a vykreslení distribuční funkce
dist.f = function(x,p){
  F = cumsum(p)
  F_ext = c(0, F) # natáhneme F o 0 na začátku
  x_ext = c(x[1]-1, x, x[length(x)]+1) # a x z obou stran
  
  plot(x, F, ylab="F(x)", xaxt='n', ylim=c(0,1), # prazdná kolečka
       type='p', main="Distribucni funkce") 
  par(new=TRUE) # že chceme kreslit do jednoho grafu
  plot(x, F_ext[1:(length(F_ext)-1)], # plná kolečka
       ylab="F(x)", xaxt='n', ylim=c(0,1), type='p', pch=19) 
  
  for(i in 1:(length(x_ext)-1)){
    lines(c(min(x)-100,max(x)+100), c(F_ext[i],F_ext[i]),
          type = 'l', lty = 3, lwd=0.5) # horizontální grid
    lines(c(x_ext[i],x_ext[i]), c(-0.1,1.1), 
          type = 'l', lty = 3, lwd=0.5) # vertikální grid
    lines(x_ext[i:(i+1)], c(F_ext[i],F_ext[i])) # graf - čáry
  }
  axis(1, at=x,labels=x) # nastavení hodnot na X
  axis(4, at=F,labels=F, las=2, cex.axis=0.7, tck=-.01) # a Y
  return(F)
}

sort.indexy = function(y, p){
  sort(y)
  idx_sorted = order(y) # funkce order vrátí indexy setřízeného pořadí
  idx_sorted
  y = y[idx_sorted]
  p_y = p[idx_sorted]
  p_y
  newList <- list("idxs" = y, "prav" = p)
  return(newList)
}

sluc.indexy = function(w, p){
  w_uniq = unique(w)
  w_uniq
  w_sorted = sort(w_uniq)
  w_sorted
  
  p_w = w_sorted*0 # inicializace pole o stejné velikosti
  for(i in 1:length(w_sorted)){
    p_w[i] = sum(p[w == w_sorted[i]])
  }
  p_w
  
  newList <- list("idxs" = w_sorted, "prav" = p_w)
  return(newList)
}

# Vypocet ciselnych charakteristik
souhrn=function(x,p){
  EX = sum(x*p)
  EX2 = sum(x*x*p)  
  DX = EX2-EX^2
  sigma.X = sqrt(DX)
  # zápis výsledků do tabulky
  tab = rbind(EX, DX, sigma.X)
  tab.popis = c("str. hodnota","rozptyl","smer. odchylka")
  rownames(tab) = tab.popis
  return(tab)
}

####################################
# POKUD JE DNV ZADANA PRAV. FUNKCI #
####################################

x = c(0,1,2,3,4,5,6) # Jednotlive x hodnoty
p = c(0.01,0.40,0.25,0.15,0.10,0,0.03) # Jednotlive pravdepodobnosti

####################################
# POKUD JE DNV ZADANA DIST. FUNKCI #
####################################

F = c(0, 0.3, 0.7, 1)
x = c(-1,0,1)
p = diff(F)

# Pouzit pokud chybi jedna hodnota
# p[6] = round(1 - sum(p), digits=2) # zápis pro x=5 je 6-tá pozice 

pravd.f(x, p) # Vykresleni pravdepodobnostni funkce

dist.f(x,p) # Vypocet a vykresleni distribucni funkce

souhrn(x, p) # Vypocet ciselnych charakteristik

# Pokud se v prikladu pocita s nasobenim X
# y = 500*x
# z=500*x-800

# Suma pravdepodobnosti, kdy hodnoty z jsou vetsi nez nula
# sum(p[z>0])

# Pokud dochazi k operaci s x a x je neserazene
y = 1 - 3*x
pravd.f(y,p)

dist.f(y,p)   # Nesmyslný výstup 
y
p
y

sorted = sort.indexy(y, p)
sorted
y = sorted$idxs
p_y = sorted$prav

pravd.f(y, p_y)

dist.f(y, p_y)

souhrn(y, p_y)


# Pokud dochazi k operaci s x a nejaka hodnota x je obsazena dvakrat
w = 3*x*x
w

pravd.f(w,p)
dist.f(w,p)

w

sluc = sluc.indexy(w, p)
w = sluc$idxs
p_w = sluc$prav

pravd.f(w, p_w)
dist.f(w, p_w)
souhrn(w, p_w)
