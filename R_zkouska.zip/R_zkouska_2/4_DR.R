# ** Pravděpodobnostní funkce ####
# - začíná písmenkem d: p = P(X = x): p = d...(x, ...)
# 
# ** Kumulativní pravděpodobnostní (Distribuční funkce) ####
# - začíná písmenkem p: p = P(X <= x): p = p...(x, ...)
# - pozor Kumulativní pravděpodobnostní je s alternativní definicí P(X <= t)
# - pro naši distribuční funkci F(t) = P(X<t): F(t) = p...(t - 1, ...)
# 
# ** Kvantilová funkce ####
# - začíná písmenkem q: p => P(X <= x): x = q...(p, ...)
# - hledá nejmenší x pro které je P(X <= x) větší než p





# * Binomické (Alternativní): Bi(n, pi), A(π) = Bi(1, pi)$ ####
# - počet úspěchů v n Bernoulliho pokusech (případně pro jeden pokus v případě Alternativní)
# - každý pokus má šanci na úspěch pi


# Pravděpodobnostní funkce P(X = x)
x = 10   # hodnota, pro níž hledáme p-stní funkci 
n = 21   # rozsah výběru
p = 0.5  # pravděpodobnost úspěchu
dbinom(x, n, p)

options(warn=-1) # tímto se dají vypnout warningy

options(warn=0) # tímto zase zapnout

# vykreslíme si pravděpodobnostní funkci
x = 0:n # minimálně 0, maximálně n má kladnou pravděpodobnost
P_x = dbinom(x, n, p)
plot(x, P_x)
grid()

# Kumulativní pravděpodobnostní funkce P(X <= x)
x = 10   # hodnota, pro níž hledáme kumulativní p-stní funkci 
n = 21   # rozsah výběru
p = 0.5  # pravděpodobnost úspěchu
pbinom(x, n, p)

# Distribuční funkce F(x) = P(X < x)
x = 10   # hodnota, pro níž hledáme kumulativní p-stní funkci 
n = 21   # rozsah výběru
p = 0.5  # pravděpodobnost úspěchu
pbinom(x, n, p) - dbinom(x, n, p)
# nebo
pbinom(x - 1, n, p)

# vykreslíme si distribuční funkci
x = 0:n # minimálně 0, maximálně n má kladnou pravděpodobnost
P_x = dbinom(x, n, p)
F_x = cumsum(P_x)
plot(x, F_x, type='s')
grid()

# najdi x pro dané q: q = P(X <= x)
q = 0.7  # h
n = 21   # rozsah výběru
p = 0.5  # pravděpodobnost úspěchu
qbinom(q, n, p)

# Kvantilová funkce (inverzi dist. fce): q = F(x) = P(X < x)
q = 0.7   # pravděpodobnost pro kterou hledáme kvantil
n = 21   # rozsah výběru
p = 0.5  # pravděpodobnost úspěchu
qbinom(q, n, p) + 1





# * Hypergeometrické: H(N, M, n) ####
# - počet úspěchů v n závislých pokusech
# - závislost typu: 
#  - N objektů, 
#  - z toho M objektů se zadanou vlastností, 
#  - výběr velikosti n
#  - při výběru nevracíme zpět - pravděpodobnost výběru objektu s danou vlastností se
# mění s každým dalším vybraným objektem
# - R funkce bere jako parametry hyper(k, M, N - M, n)
#  - k je počet úspěchů pro které počítáme pravděpodobnost,
#  - M je počet objektů se zadanou vlastností,
#  - N-M je počet objektů bez zadané vlastnosti,
#  - n je ceklová velikost výběru.


# Pravděpodobnostní funkce P(X = x)
x = 5   # hodnota, pro níž hledáme p-stní funkci 
N = 20  # celkový počet objektů
M = 5   # z toho se zadanou vlastností
n = 10  # velikost výběru
dhyper(x, M, N - M, n)

# vykreslíme si pravděpodobnostní funkci
x = 0:n # minimálně 0, maximálně n nebo M má kladnou pravd.
P_x = dhyper(x, M, N - M, n)
plot(x, P_x)
grid()

# Distribuční funkce F(x) = P(X < x)
x = 5   # hodnota, pro níž hledáme dist. funkci 
N = 20  # celkový počet objektů
M = 5   # z toho se zadanou vlastností
n = 10  # velikost výběru
phyper(x - 1, M, N - M, n)

# vykreslíme si Distribuční funkci
x = 0:n # minimálně 0, maximálně n nebo M má kladnou pravd.
P_x = dhyper(x, M, N - M, n)
F_x = cumsum(P_x) 
plot(x, F_x, type='s')
grid()

# Kvantilová funkce (inverzi dist. fce): q = P(X < x)
q = 0.7 # pravděpodobnost pro kterou hledáme kvantil
N = 20  # celkový počet objektů
M = 5   # z toho se zadanou vlastností
n = 10  # velikost výběru
qhyper(q, M, N - M, n) + 1




# * Negativně binomické (Geometrické): NB(k, pi), Ge(π) = NB(1, pi) ####
# - počet pokusů do k. úspěchu (včetně)
# - každý pokus má šanci na úspěch pi
# - Negativně binomická NV je v Rku definována jako počet neúspěchů před k-tým úspěchem
# - proto jako první parametr budeme posílat x - k


# Pravděpodobnostní funkce P(X = x)
x = 15   # počet pokusů pro který hledáme pravd. fci
k = 5    # požadovaný počet úspěchů
p = 0.3  # pravd. jednotlivých pokusů
dnbinom(x - k, k, p)

# vykreslíme si pravděpodobnostní funkci
x = 0:40 # minimálně k, maximum neomezeno
P_x = dnbinom(x - k, k, p)
plot(x, P_x)
grid()

# Distribuční funkce F(x) = P(X < x)
x = 15   # počet pokusů pro který hledáme pravd. fci
k = 5    # požadovaný počet úspěchů
p = 0.3  # pravd. jednotlivých pokusů
pnbinom(x - k - 1, k, p)

# vykreslíme si Distribuční funkci
x = 0:40 # minimálně 0, maximálně n nebo M má kladnou pravd.
P_x = dnbinom(x - k, k, p)
F_x = cumsum(P_x)
plot(x, F_x, type='s')
grid()

# Kvantilová funkce (inverzi dist. fce): q = P(X < x)
q = 0.7  # pravd. pro kvantil
k = 5    # požadovaný počet úspěchů
p = 0.3  # pravd. jednotlivých pokusů
qnbinom(q, k, p) + k + 1






# * Poissonovo:  Po(λt) ####
# - počet událostí v Poissonově procesu v uzavřené oblasti (v čase, na ploše, v objemu)
# - s hustotou výskytu λ
# - v čase/ploše/objemu velikosti t


# Pravděpodobnostní funkce P(X = x)
x = 9       # počet pokusů pro který hledáme pravd. fci
lambda = 5  # hustota výskytu
t = 2       # pravd. jednotlivých pokusů
lt = lambda*t
dpois(x, lt)

# vykreslíme si pravděpodobnostní funkci
x = 0:25 # minimálně 0, maximum neomezeno
P_x = dpois(x, lt)
plot(x, P_x)
grid()

# Distribuční funkce F(x) = P(X < x)
x = 9       # počet pokusů pro který hledáme pravd. fci
lambda = 5  # hustota výskytu
t = 2       # pravd. jednotlivých pokusů
lt = lambda*t
ppois(x - 1, lt)

# vykreslíme si Distribuční funkci
x = 0:25 # minimálně 0, maximálně n nebo M má kladnou pravd.
P_x = dpois(x, lt)
F_x = cumsum(P_x)
plot(x, F_x, type='s')
grid()

# Kvantilová funkce (inverzi dist. fce): q = P(X < x)
q = 0.4     # pravd. pro kvantil
lambda = 5  # hustota výskytu
t = 2       # pravd. jednotlivých pokusů
lt = lambda*t
qpois(q, lt) + 1