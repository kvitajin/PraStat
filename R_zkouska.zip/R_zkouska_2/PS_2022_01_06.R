##### 2

dolni_mez = 0 # dolni mez pro integral
horni_mez = 6 # horni mez pro integral

f = function(x){
  return(6*x - x*x)
} 

c_konst = integrate(f, dolni_mez, horni_mez)$value
c_konst
# c = 1/c_konst

#### a

f.dens = function(x){
  res = 1/36*(6*x - x*x) # zadat vysledek z derivace s vypocitanou konstantou
  res[x <= dolni_mez] = 0 # 0 pro x <= dolni mez
  res[x > horni_mez] = 0  # 0/1 pro x > horni mez
  return(res)
}

# Vykresleni hustoty pravdepodobnosti
x = seq(from = dolni_mez - 2, to = horni_mez + 2, by = 0.01) # body na ose x
fx = f.dens(x) # hodnoty f(x)
plot(x, fx, cex=0.2) # vykreslit tečky (cex je velikost)

#### b
f = function(x){
  return(1/36*((3*x*x) - (x*x*x)/3))
} 

F.dist = function(x){
  res = 1/36*((3*x*x) - (x*x*x)/3) # funkce k pocitani v distribucni funkci s vypocitanou konstantou
  res[x <= dolni_mez] = 0 # 0 pro x <= dolni mez
  res[x > horni_mez] = 1  # 1 pro x > horni mez
  return(res)
}


# Vykresleni distribucni funkce
x = seq(from = dolni_mez - 2, to = horni_mez + 2, by = 0.001) # body na ose x
FX = F.dist(x)
plot(x, FX, type='l')

#### c

dolni_mez = 2
f_ssss = function(x){
  return(1/36*(6*x - x*x))
} 
integrate(f_ssss, dolni_mez, horni_mez)$value


#### d
x[FX >= 0.66][1]

#### 3 
# Hustota pravděpodobnosti f(x)
lambda = 1/45


# vykreslíme si Hustotu pravděpodobnosti
x = seq(from = 0, to = 300, by = 0.01)
f_x = dexp(x, lambda)
plot(x, f_x, type='l')
grid()

1 - pexp(60, lambda)


x = 14   # hodnota, pro níž hledáme p-stní funkci 
n = 30   # rozsah výběru
p = 0.2635971  # pravděpodobnost úspěchu
1 - pbinom(x, n, p)
